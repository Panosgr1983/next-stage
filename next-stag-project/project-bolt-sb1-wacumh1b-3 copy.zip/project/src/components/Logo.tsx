import React from 'react';
import { Monitor } from 'lucide-react';

const Logo: React.FC = () => {
  return (
    <a href="#home" className="flex items-center space-x-2">
      <Monitor className="h-8 w-8 text-[#6ab04c] dark:text-[#6ab04c]" />
      <div className="flex flex-col">
        <span className="text-xl font-bold text-white dark:text-white">NextStage</span>
        <span className="text-xs uppercase tracking-wider text-[#6ab04c] dark:text-[#6ab04c]">Technology Solutions</span>
      </div>
    </a>
  );
};

export default Logo;