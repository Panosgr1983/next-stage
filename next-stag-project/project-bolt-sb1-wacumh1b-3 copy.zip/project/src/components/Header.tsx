import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { Menu, X, Moon, Sun, Phone } from 'lucide-react';
import Logo from './Logo';

interface HeaderProps {
  toggleDarkMode: () => void;
  darkMode: boolean;
}

const Header: React.FC<HeaderProps> = ({ toggleDarkMode, darkMode }) => {
  const { t } = useTranslation();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const navLinks = [
    { name: t('nav.home'), href: '#home' },
    { name: t('nav.services'), href: '#services' },
    { name: t('nav.about'), href: '#about' },
    { name: t('nav.gallery'), href: '#gallery' },
    { name: t('nav.testimonials'), href: '#testimonials' },
    { name: t('nav.contact'), href: '#contact' },
  ];

  return (
    <header 
      className={`fixed w-full z-50 transition-all duration-300 ${
        scrolled 
          ? 'bg-white/90 dark:bg-slate-900/90 backdrop-blur-md shadow-md py-2' 
          : 'bg-transparent py-4'
      }`}
    >
      <div className="container mx-auto px-4 flex justify-between items-center">
        <Logo />
        
        <div className="hidden md:flex items-center space-x-8">
          <nav>
            <ul className="flex space-x-6">
              {navLinks.map((link) => (
                <li key={link.name}>
                  <a 
                    href={link.href}
                    className={`font-medium transition-colors duration-200 ${
                      scrolled
                        ? 'text-slate-700 dark:text-slate-200 hover:text-[#6ab04c] dark:hover:text-[#6ab04c]'
                        : 'text-white hover:text-[#6ab04c]'
                    }`}
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </nav>
          
          <div className="flex items-center space-x-4">
            <button 
              onClick={toggleDarkMode}
              className="p-2 rounded-full hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors duration-200"
              aria-label={darkMode ? t('accessibility.lightMode') : t('accessibility.darkMode')}
            >
              {darkMode ? <Sun size={20} className="text-white" /> : <Moon size={20} className="text-white" />}
            </button>
            
            <a 
              href="tel:2102116016" 
              className="flex items-center space-x-2 text-[#6ab04c] font-semibold"
            >
              <Phone size={18} />
              <span>210 21 16 016</span>
            </a>
          </div>
        </div>
        
        <div className="md:hidden flex items-center">
          <button 
            onClick={toggleDarkMode}
            className="p-2 mr-2 rounded-full hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors duration-200"
            aria-label={darkMode ? t('accessibility.lightMode') : t('accessibility.darkMode')}
          >
            {darkMode ? <Sun size={20} className="text-white" /> : <Moon size={20} className="text-white" />}
          </button>
          
          <button 
            onClick={toggleMenu}
            className="p-2 rounded-md hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors duration-200"
            aria-label={isMenuOpen ? t('accessibility.closeMenu') : t('accessibility.openMenu')}
          >
            {isMenuOpen ? <X size={24} className="text-white" /> : <Menu size={24} className="text-white" />}
          </button>
        </div>
      </div>
      
      {/* Mobile Menu */}
      <div 
        className={`md:hidden absolute w-full bg-white dark:bg-slate-800 shadow-lg transition-transform duration-300 ease-in-out ${
          isMenuOpen ? 'translate-y-0' : '-translate-y-full'
        }`}
      >
        <nav className="container mx-auto px-4 py-4">
          <ul className="space-y-4">
            {navLinks.map((link) => (
              <li key={link.name}>
                <a 
                  href={link.href}
                  className="block py-2 font-medium text-slate-700 dark:text-slate-200 hover:text-[#6ab04c] dark:hover:text-[#6ab04c]"
                  onClick={() => setIsMenuOpen(false)}
                >
                  {link.name}
                </a>
              </li>
            ))}
            <li className="pt-2 border-t border-slate-200 dark:border-slate-700">
              <a 
                href="tel:2102116016" 
                className="flex items-center space-x-2 py-2 text-[#6ab04c] font-semibold"
              >
                <Phone size={18} />
                <span>210 21 16 016</span>
              </a>
            </li>
          </ul>
        </nav>
      </div>
    </header>
  );
};

export default Header;