import React from 'react';
import { useTranslation } from 'react-i18next';

const LanguageToggle: React.FC = () => {
  const { i18n } = useTranslation();
  
  const toggleLanguage = () => {
    const newLang = i18n.language === 'en' ? 'el' : 'en';
    i18n.changeLanguage(newLang);
    localStorage.setItem('language', newLang);
  };

  return (
    <button
      onClick={toggleLanguage}
      className="fixed bottom-8 left-8 z-40 p-2 bg-white dark:bg-slate-800 rounded-full shadow-lg hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors duration-200"
      aria-label="Toggle language"
    >
      <img 
        src={i18n.language === 'en' ? '/gr.svg' : '/uk.svg'} 
        alt={i18n.language === 'en' ? 'Ελληνικά' : 'English'}
        className="w-6 h-6"
      />
    </button>
  );
};

export default LanguageToggle;