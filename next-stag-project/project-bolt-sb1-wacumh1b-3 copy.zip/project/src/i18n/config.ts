import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import enTranslation from './locales/en';
import elTranslation from './locales/el';

i18n.use(initReactI18next).init({
  resources: {
    el: {
      translation: elTranslation
    },
    en: {
      translation: enTranslation
    }
  },
  lng: 'el', // Default language is Greek
  fallbackLng: 'en',
  interpolation: {
    escapeValue: false
  }
});

export default i18n;